#include "ext/tty.h"
#include "ext/system.h"

void main(void) {
    print("NNL Kernel 1.0");
    cpudo("hlt");
}