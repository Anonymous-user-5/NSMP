extern void shutdown();

#ifndef SYSTEM_H
#define SYSTEM_H

void cpudo(char* activity) {
    if ("hlt" == activity) {
        shutdown();
    }
}

#endif