#ifndef TTY_H
#define TTY_H

void print(const char* str);

#endif